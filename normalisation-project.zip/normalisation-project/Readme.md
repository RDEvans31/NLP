This folder is being used to store all the research and experimental code used in the development of normalisation api.

Setting up environment:
 - Download Anaconda
 - Create an environment
 - Make sure pip is installed in your environment
 - pip3 install -r requirements.txt

 You should be okay to run any tools you need to continue development.
